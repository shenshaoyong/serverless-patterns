# File generated from our OpenAPI spec by Stainless.

from typing import TypeVar

from ._models import BaseModel

_BaseModelT = TypeVar("_BaseModelT", bound=BaseModel)
